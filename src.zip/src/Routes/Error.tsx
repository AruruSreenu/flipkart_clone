const ErrorPage = () => {
  return <div>error</div>;
};

export default ErrorPage;
