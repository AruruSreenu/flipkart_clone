import Routes from "./Routes/Home/Route";
import { Provider } from "react-redux";
// import { store } from "./store/Store";

import "./App.css";

function App() {
  return (
    // <Provider store={store}>
    <Routes />
    // </Provider>
  );
}

export default App;
