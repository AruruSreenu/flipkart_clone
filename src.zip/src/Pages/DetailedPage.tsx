import ProductDetailed from "../components/Products/ProductDetailed";

const DetailedPage = () => {
  return <ProductDetailed />;
};

export default DetailedPage;
