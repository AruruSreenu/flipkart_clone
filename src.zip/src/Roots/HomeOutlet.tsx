import { Outlet } from "react-router-dom";

const HomeOutlet = () => {
  return <Outlet />;
};

export default HomeOutlet;
